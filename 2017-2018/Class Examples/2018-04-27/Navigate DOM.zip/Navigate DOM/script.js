document.getElementById("button").addEventListener("click", doSomething);

function doSomething() {
  console.log("Button Pressed");
}